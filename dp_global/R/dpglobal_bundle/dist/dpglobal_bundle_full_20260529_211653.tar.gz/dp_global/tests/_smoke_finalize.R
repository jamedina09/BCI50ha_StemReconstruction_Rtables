## Smoke test: source all dp_global/R modules + end-to-end finalize round-trip.
suppressMessages({
    library(data.table)
    library(Rcpp)
})

src_files <- list.files("dp_global/R", "\\.R$", full.names = TRUE)
for (f in src_files) {
    cat("Source:", f, "... ")
    source(f, local = FALSE)
    cat("OK\n")
}

stopifnot(is.function(finalize_posterior_paths))
stopifnot(is.function(renumber_engine_minted_ids))
stopifnot(is.function(apply_bb_invariants_to_samples))

# ---- Round-trip test of finalize_posterior_paths --------------------------
tmp <- tempfile("dp_finalize_smoke_")
dir.create(tmp)
post_dir <- file.path(tmp, "posteriors")
dir.create(post_dir)
staging_dir <- file.path(post_dir, ".staging")
dir.create(staging_dir)

# Build a minimal `out` data.table for Tag 999 with two censuses, three rows
# in renumbered ID space (engine IDs negative-ish; one real DB id stays).
out <- data.table(
    Tag = 999L,
    CensusID = c(1L, 2L, 1L, 2L),
    obs_row_id = 1:4,
    StemTag = c("A", "A", "B", "B"),
    Status = c("A", "A", "A", "A"),
    DBH = c(50, 55, 30, 33),
    ReconstructedStemID = c(101L, 101L, 102L, 102L), # renumbered
    TrueStemID = c(NA_integer_, NA_integer_, NA_integer_, NA_integer_),
    ReconstructionMethod = c("dp", "dp", "dp", "dp")
)

# Build a raw samples_dt in pre-renumber space (old_ids 5 and 7)
samples_dt <- data.table(
    Tag = 999L,
    Sample = rep(1:3, each = 4),
    CensusID = rep(c(1L, 2L, 1L, 2L), 3),
    ReconstructedStemID = c(
        5L, 5L, 7L, 7L,
        5L, 5L, 7L, 7L,
        5L, 5L, 7L, 7L
    ),
    ObsRowID = rep(1:4, 3),
    logp = rep(c(-10, -10, -10.5), each = 4)
)

# Mapping table: old_id -> new_id translation
mapping <- data.table(
    Tag = c(999L, 999L),
    old_id = c(5L, 7L),
    new_id = c(101L, 102L),
    first_census = c(1L, 1L)
)

# Stage the file as the engine would
ts_local <- "20250101_000000"
stage_path <- file.path(staging_dir, paste0("tag_999_samples_raw_", ts_local, ".rds"))
saveRDS(list(
    engine = "dp",
    tag_val = 999L,
    batch_ts = ts_local,
    posterior_samples_format = "csv",
    posterior_samples_path = tmp,
    samples_dt = samples_dt,
    sampling_profile = list(posterior_samples = 3L)
), file = stage_path)

# Run finalize
res <- finalize_posterior_paths(out,
    posterior_samples_path = tmp,
    mapping = mapping, verbose = TRUE
)
cat("Result:", str(res), "\n")
stopifnot(res$n_written == 1L, res$n_failed == 0L)
stopifnot(!file.exists(stage_path)) # staging removed after success

# Read the produced paths file
paths_file <- file.path(post_dir, "tag_999_posterior_samples_20250101_000000_paths.csv")
stopifnot(file.exists(paths_file))
paths <- fread(paths_file)
cat("\nPaths summary:\n")
print(paths)
# All three samples collapse to one identical path_sig "101-101-102-102"
stopifnot(nrow(paths) == 1L)
stopifnot(paths$path_count == 3L)
stopifnot(grepl("101", paths$path_sig)) # confirm renumbered ID present
stopifnot(!grepl("\\b5\\b", paths$path_sig)) # confirm old id replaced
cat("\n[SMOKE TEST PASSED] finalize_posterior_paths round-trip OK.\n")
