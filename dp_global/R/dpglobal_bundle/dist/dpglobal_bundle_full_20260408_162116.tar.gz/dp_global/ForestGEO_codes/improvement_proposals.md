# Proposals to Improve Stem Reconstruction & Reduce Transitions

## Status of Implemented Changes

| Change | Status | Files |
|--------|--------|-------|
| M-code main-stem pinning | ✅ Done | `dp_global_dp.R` L1206–1243 |
| R-recruit constraint (R/RP/RF/RT/QR/OR) | ✅ Done | `dp_global_dp.R` L1252–1282 |
| OR added to resprout regex | ✅ Done | `dp_global_dp.R`, `estimate_dp_complexity_function.R` |
| MF exclusion for R-coded NA censuses | ✅ Done | `dp_global_dp.R` L284–289 |
| Anchor extension (dead anchor → post-anchor) | ✅ Done | `dp_global_dp.R` L481–498 |
| `perl=TRUE` on all `\b` regex calls | ✅ Done | `dp_global_dp.R` (6 calls) |
| `which.min` tie-breaker for determinism | ✅ Done | `dp_global_dp.R` L1488–1491 |
| Pruning summary counter fix | ✅ Done | `dp_global_dp.R` L1289–1292 |

---

## Proposal 1: Z Code — Previously Dead, Now Alive

### Code definition
- **Z** = "Previously dead, now alive" (`DFstatus = alive`)
- Frequency: ~35 records in BCI data

### What it means for the DP
A Z-coded stem was **dead** in a prior census and has come back to life. Going backward
in time, this stem did NOT exist before — it is a **new recruit** at the census where Z
appears. Semantically identical to R-recruit.

### Implementation
Add `\bZ\b` detection to the R-recruit constraint (backward loop, L1252–1282).
Do **NOT** add Z to the resprout regex used for:
- MF exclusion (Z means alive, not NA-barrier)
- Resprout barrier / K computation (Z doesn't increase K — the stem already existed
  in the anchor census TrueStemID set)

### What to watch out for
- Z with `DBH = NA`: should be treated as MF (alive but unmeasured), not as R-recruit.
  Only apply R-recruit constraint when Z has non-NA DBH.
- Z on a stem that was "dead" for only 1 census (transient death): the field team may
  have incorrectly called it dead, then found it alive. In this case the Z constraint
  forces a track break that may be wrong. **Recommendation**: only apply Z-recruit when
  the stem was dead for ≥ 2 consecutive censuses. This requires looking backward from
  the Z census to count consecutive NA/dead records on the same physical stem — which
  we don't have (that's what we're trying to reconstruct). Safe conservative approach:
  apply Z-recruit unconditionally but log it for manual review.

### Expected impact
- Accuracy: small improvement (35 records)
- Timing: negligible

---

## Proposal 2: Stem-Dead Identity Constraint (N, S, T, C codes)

### Code definitions
| Code | Meaning | DFstatus | Frequency (C8+C9) |
|------|---------|----------|--------------------|
| N | Stem dead, tree alive | dead | ~15,000 |
| S | Stem dead, tree alive | dead | ~8,000 |
| T | Stem dead, tree alive | dead | ~4,000 |
| C | Stem dead, tree alive | dead | ~3,000 |
| Ns, Ss, Ts, Cs | Dead + sprouting variant | dead | ~2,000 |

### What it means for the DP
These codes tell us a specific stem **within a multi-stemmed tree** has died. The tree
is still alive through other stems. Going forward in time from census C where a stem
has code N/S/T/C:

1. The track occupied by that stem should become **empty** at C+1
2. If the stem reappears at C+1 with a sprouting variant (Ns, Ss), it is a new organism
   → R-recruit semantics

### Current behavior
Most stem-dead rows have `DBH = NA` → filtered out → invisible to DP. The DP doesn't
know the stem died and may assign a **new recruit** at C+1 to the dead stem's track,
creating false continuity.

### Implementation approach

#### Option A: Forward dead-track constraint (recommended)
In the backward transition step from C_p → C_{p+1}:
- If a track `k` is **occupied** at C_{p+1} AND the observation at C_{p+1} has a
  stem-dead code (N/S/T/C without sprouting suffix):
  - Track `k` **must be empty** at C_p (the stem died going forward, so going backward
    it must have appeared here)
  - Wait — this is wrong. Going backward, "stem dead at C_{p+1}" means the stem
    existed at C_{p+1} and died by C_p. So track k at C_p should be empty.
  - Actually: dead stems have `DBH = NA` → they are NOT in `obs_dbh`. They don't
    appear in the state enumeration at all. The DP already treats them as absent.

**The real value is different**: when we know stem X is dead at C8, and we see 3 stems
at C7 and 2 at C8 (one died), the stem-dead code tells us WHICH stem died → we can
constrain which C7 observation maps to which C8 observation.

#### Option B: Inform K computation (simpler)
Currently K is computed from observation counts + resprouts. Stem-dead codes at the
anchor can tell us: "this stem existed at the anchor but is now dead" → it should still
be counted in K. This is already handled because dead stems at the anchor still have
`TrueStemID` entries. No change needed.

#### Option C: DBH = NA stem-dead rows as soft evidence
Include stem-dead `DBH = NA` rows in the state enumeration as a **special "dead"
observation** that can only map to an empty (NA) track. This effectively constrains the
number of empty tracks at that census to be ≥ number of dead stems.

### What to watch out for
- **Field errors**: stems marked dead that are found alive later (codes may be wrong in
  5–10% of cases per ForestGEO documentation). Do NOT hard-constrain; use as soft
  evidence with a penalty cost rather than infeasible pruning.
- **Sprouting variants** (Ns, Ss, Ts, Cs): these mean "dead stem with sprout at base."
  The sprout is a new organism. Treat these like R-recruit (new track going backward)
  AND dead-track (the original stem's track becomes empty).
- **Overlap with existing codes**: a stem can have both N and R in `ListOfTSM` (e.g.,
  "N;R" = stem dead, resprouted). The R-recruit constraint already handles the resprout
  part. The N part is redundant in this case.

### Expected impact
- Accuracy: moderate improvement for multi-stemmed trees with stem mortality
- Timing: **significant reduction** — knowing which stems died constrains the matching
  matrix. For a tag with K=8 where 3 stems die between C6→C7, the effective matching
  at C6 drops from P(8,5) = 6720 to P(5,5) × C(8,3) = 120 × 56 = far fewer feasible
  transitions (exact reduction depends on implementation).

### Recommended implementation order
1. Start with Option C (include dead rows as soft evidence) — simplest
2. Validate on tags where stem death is known (BCI census 8–9 transitions)
3. If accuracy improves, add hard constraint (Option A) with a field-error tolerance

---

## Proposal 3: POM (Point of Measure) Growth Relaxation

### Code definitions
| Code | Meaning |
|------|---------|
| P | POM changed (general) |
| PB | POM changed to below previous |
| PN | POM changed to new location |
| PT | POM changed to top |
| PV | POM changed vertically |
| PK | POM changed, previously known |

### What it means for the DP
When POM changes, the measured DBH can jump dramatically — a tree measured at 1.3m
might now be measured at 0.5m, causing an apparent "growth" of 5+ cm in one interval.
This is **not real growth or shrinkage** — it's simply a different measurement point on
the same stem.

### Current behavior
The DP applies fixed growth bounds (`MAX_GROWTH_FIXED`, `MAX_SHRINK_FIXED`) to ALL
transitions. When a POM change causes an apparent jump exceeding these bounds, the
transition is **pruned as infeasible**. This means:
- The correct identity match is rejected
- The stem gets assigned to a wrong track or falls back to igraph
- This is a **false negative** in pruning

### Implementation approach

#### Option A: Per-observation bound override (recommended)
When an observation has a P-family code in `ListOfTSM`:
1. Widen the growth/shrinkage bounds for that specific track by a configurable
   multiplier (e.g., `POM_GROWTH_MULTIPLIER = 3.0`)
2. This requires passing per-observation flags to the Rcpp `derive_phase_prev_batch_rcpp`
   function, which currently applies uniform bounds

**Rcpp changes needed** in `transition_cost_rcpp.cpp`:
- Add a `pom_flag` boolean vector parameter (length K, one per track)
- When `pom_flag[k] == true`, use `eff_min * POM_MULT` and `eff_max * POM_MULT`
  instead of the standard bounds for track k

**R changes needed** in `dp_global_dp.R`:
- Pre-compute `is_pom_obs[[p]]` per census: `grepl("\\b(P|PB|PN|PT|PV|PK)\\b", ...)`
- Pass to the Rcpp function in the backward loop

#### Option B: Skip pruning entirely for POM observations (simpler but less safe)
When ANY observation at census p+1 has a P-family code, disable hard pruning for ALL
transitions into that census. This is too aggressive — it disables pruning for all
tracks, not just the POM-affected one.

### What to watch out for
- **POM at anchor census**: the anchor DBH is the reference point. If POM changed AT
  the anchor, all backward growths are relative to a shifted baseline. Do NOT widen
  bounds at the anchor — instead, widen bounds at the **previous** census.
- **Cascading POM**: if POM changes at C5 and again at C7, both transitions C4→C5 and
  C6→C7 need relaxed bounds. Each is independent.
- **False positives**: widening bounds allows biologically implausible transitions to
  survive pruning. Mitigate by using a moderate multiplier (2–3×, not unlimited).
- **Transition cost**: even with relaxed pruning, the transition COST should still
  penalize large jumps. The cost function already computes growth rate × penalty — this
  naturally discourages POM-inflated transitions from winning unless they're the only
  feasible option.
- **Rcpp recompilation**: any change to `transition_cost_rcpp.cpp` requires recompiling
  the shared library. Test on simulated data with artificial POM jumps first.

### Expected impact
- Accuracy: significant improvement for tags with POM changes (common in long-term
  census data where measurement protocols change)
- Timing: small INCREASE in transitions (fewer pruned), but better accuracy means fewer
  igraph fallbacks, which are slower than DP

### Testing approach
1. Add simulated tags to `simulate_data.R` with artificial POM jumps
2. Verify that without relaxation, the tag gets wrong ReconstructedStemID
3. Verify that with relaxation, the tag gets correct ReconstructedStemID
4. Run full BCI data before/after and compare transition counts

---

## Proposal 4: B Code — Broken Above, Stem Alive

### Code definition
- **B** = "Broken above measurement point" (`DFstatus = alive`)
- Frequency: ~12,000 records at C8–C9

### What it means for the DP
A B-coded stem was broken above the measurement point. The DBH measurement is valid
(the break is above), but the stem may show apparent "negative growth" in the next
census because the remaining trunk can shrink or the stem may die.

### Current behavior
B-coded stems are treated as normal observations. No special handling.

### Possible use
- **Shrinkage relaxation**: when a stem is B-coded at census C, relax the shrinkage
  bound at the C→C+1 transition. The stem may lose apparent diameter as the broken top
  dries out. Not recommended as a priority — the existing shrinkage bound (-0.5 cm/yr)
  already accommodates moderate shrinkage.
- **Death prediction**: B-coded stems are more likely to die in subsequent censuses.
  This is informational but doesn't directly help stem matching.

### Expected impact
- Minimal. B-coded stems have valid DBH and identity matching works normally.
- Only relevant if the post-break shrinkage exceeds MAX_SHRINK_FIXED.

---

## Proposal 5: Sprouting Variant Codes (Ns, Ss, Ts, Cs) as R-recruit

### Code definitions
| Code | Meaning |
|------|---------|
| Ns | Stem dead, new sprout at base |
| Ss | Stem dead, new sprout at base |
| Ts | Stem dead, new sprout at base |
| Cs | Stem dead, new sprout at base |

### What it means for the DP
The lowercase `s` suffix means "sprouting at base." The original stem is dead (same as
N/S/T/C) but a new sprout has emerged. Going backward, this sprout is a **new organism**
— it should receive R-recruit semantics (track must be empty at prior census).

### Implementation
1. If the sprouting variant has `DBH > 0` (the sprout was measured): treat as R-recruit
   (add to the resprout regex or handle separately)
2. If `DBH = NA`: same as regular stem-dead code — the sprout wasn't big enough to
   measure. No track assignment needed.

### What to watch out for
- The `s` suffix is lowercase. Regex must be case-sensitive or use explicit patterns:
  `\\b(Ns|Ss|Ts|Cs)\\b`
- These may co-occur with other codes in the same `ListOfTSM` field (semicolon-separated)
- Frequency is low (~2,000 records), so impact is modest

---

## Implementation Priority Order

| Priority | Proposal | Complexity | Impact on accuracy | Impact on timing |
|----------|----------|-----------|-------------------|-----------------|
| 1 | ~~OR in resprout regex~~ | ✅ Done | Moderate | Moderate reduction |
| 2 | Z as R-recruit | Trivial (1 line) | Small | Negligible |
| 3 | Stem-dead constraint (N/S/T/C) | Moderate | Moderate-large | Large reduction |
| 4 | POM growth relaxation | High (Rcpp) | Significant | Small increase |
| 5 | Sprouting variants (Ns/Ss/Ts/Cs) | Low | Small | Small reduction |
| 6 | B-code shrinkage relaxation | Low | Minimal | None |

---

## General Testing Protocol

For each new constraint:
1. Run baseline on simulated data (no codes present) → save CSV
2. Implement change
3. Rerun on simulated data → compare: must be 100% identical
4. Add simulated tags WITH the relevant code → verify correct reconstruction
5. Run on BCI sample (`--SAMPLE_N=500`) → check for regressions and improvements
6. Run on specific known-problematic BCI tags → verify fix

<!-- pandoc improvement_proposals.md -o improvement_proposals.pdf -->