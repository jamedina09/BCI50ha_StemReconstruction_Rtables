############################################################
### test_broken_below_invariants.R
###
### Unit tests for apply_broken_below_invariants() and
### apply_bb_invariants_to_samples() — the post-engine pass
### that enforces the broken-below contract:
###   R1 (split-on-break)   : a BB+DBH row must NOT reuse the
###     ReconstructedStemID of any prior alive row in the same
###     (Tag, StemTag) series.
###   R2 (terminate-on-stump): a BB+NA-DBH row terminates the
###     series; no later alive row may reuse its id.
###
### Run from project root:
###   Rscript dp_global/tests/test_broken_below_invariants.R
############################################################

suppressPackageStartupMessages({
    library(data.table)
    library(here)
})

source(here::here("dp_global", "R", "dp_global_main.R"))

`%||%` <- function(a, b) if (is.null(a)) b else a

# ---- tiny ad-hoc test framework ----
.tests_run <- 0L
.tests_failed <- 0L
expect <- function(label, ok, msg = "") {
    .tests_run <<- .tests_run + 1L
    if (isTRUE(ok)) {
        cat(sprintf("  ok   %s\n", label))
    } else {
        .tests_failed <<- .tests_failed + 1L
        cat(sprintf("  FAIL %s   %s\n", label, msg))
    }
}

mk <- function(rows) {
    d <- as.data.table(rows)
    if (!("ReconstructionMethod" %in% names(d))) d[, ReconstructionMethod := NA_character_]
    d
}

# ---- Fixture A: simple R1 (BB+DBH must split from prior live row) ----
cat("\n[A] simple R1 split\n")
A <- mk(list(
    Tag = c(1, 1, 1),
    StemTag = c(10, 10, 10),
    CensusID = c(1, 2, 3),
    Status = c("alive", "alive", "broken below"),
    DBH = c(5, 6, 2),
    ReconstructedStemID = c(100, 100, 100)
))
A2 <- apply_broken_below_invariants(copy(A), verbose = FALSE)
expect("A.recon[1:2] unchanged", all(A2$ReconstructedStemID[1:2] == 100))
expect("A.recon[3] split to new id",  A2$ReconstructedStemID[3] != 100)
expect("A.method[3] == bb_split", identical(A2$ReconstructionMethod[3], "bb_split"))

# ---- Fixture B: R1 with a tail of carried alive rows ----
cat("\n[B] R1 with carried alive tail\n")
B <- mk(list(
    Tag = rep(1, 5),
    StemTag = rep(10, 5),
    CensusID = 1:5,
    Status = c("alive", "alive", "broken below", "alive", "alive"),
    DBH = c(5, 6, 2, 3, 4),
    ReconstructedStemID = c(100, 100, 100, 100, 100)
))
B2 <- apply_broken_below_invariants(copy(B), verbose = FALSE)
new_id <- B2$ReconstructedStemID[3]
expect("B.split id is new", new_id != 100)
expect("B.tail carries split id", all(B2$ReconstructedStemID[3:5] == new_id))
expect("B.method[3]=bb_split",            identical(B2$ReconstructionMethod[3], "bb_split"))
expect("B.method[4:5]=bb_split_carry",    all(B2$ReconstructionMethod[4:5] == "bb_split_carry"))

# ---- Fixture C: R2 simple terminator + recover ----
cat("\n[C] R2 simple terminate-on-stump\n")
C <- mk(list(
    Tag = rep(1, 3),
    StemTag = rep(10, 3),
    CensusID = 1:3,
    Status = c("alive", "broken below", "alive"),
    DBH = c(5, NA, 4),
    ReconstructedStemID = c(100, 100, 100)
))
C2 <- apply_broken_below_invariants(copy(C), verbose = FALSE)
expect("C.recon[1:2] unchanged", all(C2$ReconstructedStemID[1:2] == 100))
expect("C.recon[3] split off",   C2$ReconstructedStemID[3] != 100)
expect("C.method[3]=bb_post_terminator_split",
       identical(C2$ReconstructionMethod[3], "bb_post_terminator_split"))

# ---- Fixture D: R2 with multi-row recover tail ----
cat("\n[D] R2 with multi-row recover tail\n")
D <- mk(list(
    Tag = rep(1, 5),
    StemTag = rep(10, 5),
    CensusID = 1:5,
    Status = c("alive", "broken below", "alive", "alive", "alive"),
    DBH = c(5, NA, 4, 5, 6),
    ReconstructedStemID = c(100, 100, 100, 100, 100)
))
D2 <- apply_broken_below_invariants(copy(D), verbose = FALSE)
new_id <- D2$ReconstructedStemID[3]
expect("D.recon[3:5] all carry new id", all(D2$ReconstructedStemID[3:5] == new_id) && new_id != 100)
expect("D.method[3]=bb_post_terminator_split",        identical(D2$ReconstructionMethod[3], "bb_post_terminator_split"))
expect("D.method[4:5]=bb_post_terminator_split_carry",
       all(D2$ReconstructionMethod[4:5] == "bb_post_terminator_split_carry"))

# ---- Fixture E: pin override (TrueStemID locks contract violation) ----
cat("\n[E] pin override on BB+DBH\n")
E <- mk(list(
    Tag = rep(1, 3),
    StemTag = rep(10, 3),
    CensusID = 1:3,
    Status = c("alive", "alive", "broken below"),
    DBH = c(5, 6, 2),
    ReconstructedStemID = c(100, 100, 100),
    TrueStemID = c(100, 100, 100)  # pin-locked violation
))
E2 <- apply_broken_below_invariants(copy(E), verbose = FALSE)
expect("E.recon[3] overridden despite pin", E2$ReconstructedStemID[3] != 100)
expect("E.TrueStemID[3] updated to match", E2$TrueStemID[3] == E2$ReconstructedStemID[3])
expect("E.recon[1:2]/TrueStemID[1:2] unchanged",
       all(E2$ReconstructedStemID[1:2] == 100) && all(E2$TrueStemID[1:2] == 100))

# ---- Fixture F: idempotence ----
cat("\n[F] idempotence (apply twice == apply once)\n")
F1 <- apply_broken_below_invariants(copy(B), verbose = FALSE)
F2 <- apply_broken_below_invariants(copy(F1), verbose = FALSE)
setkey(F1, Tag, StemTag, CensusID); setkey(F2, Tag, StemTag, CensusID)
expect("F.recon stable",    identical(F1$ReconstructedStemID, F2$ReconstructedStemID))
expect("F.method stable",   identical(F1$ReconstructionMethod, F2$ReconstructionMethod))

# ---- Fixture G: no-op on already-clean input ----
cat("\n[G] no-op on already-compliant input\n")
G <- mk(list(
    Tag = rep(1, 3),
    StemTag = rep(10, 3),
    CensusID = 1:3,
    Status = c("alive", "broken below", "alive"),
    DBH = c(5, 2, 4),  # BB+DBH already split
    ReconstructedStemID = c(100, 200, 200)
))
G2 <- apply_broken_below_invariants(copy(G), verbose = FALSE)
expect("G.recon unchanged", all(G$ReconstructedStemID == G2$ReconstructedStemID))
expect("G.method unchanged (no bb_* tags emitted)",
       !any(grepl("^bb_", G2$ReconstructionMethod %||% character(0))))

# ---- Fixture H: posterior helper agrees with MAP helper ----
cat("\n[H] apply_bb_invariants_to_samples on a single-sample posterior\n")
# Build a fake samples_dt + tree_data pair where one sample violates R1.
tree_data <- mk(list(
    obs_row_id = 1:3,
    Tag = rep(1, 3),
    StemTag = rep(10, 3),
    CensusID = 1:3,
    Status = c("alive", "alive", "broken below"),
    DBH = c(5, 6, 2)
))
samples_dt <- data.table(
    Tag = rep(1, 3),
    Sample = rep(1L, 3),
    CensusID = 1:3,
    ReconstructedStemID = c(100L, 100L, 100L),
    ObsRowID = 1:3
)
S2 <- apply_bb_invariants_to_samples(copy(samples_dt), tree_data, verbose = FALSE)
expect("H.posterior R1 split", S2$ReconstructedStemID[3] != 100L)
expect("H.posterior recon[1:2] unchanged", all(S2$ReconstructedStemID[1:2] == 100L))

# ---- summary ----
cat(sprintf("\n%d/%d tests passed (%d failed).\n",
            .tests_run - .tests_failed, .tests_run, .tests_failed))
if (.tests_failed > 0L) quit(status = 1L)
