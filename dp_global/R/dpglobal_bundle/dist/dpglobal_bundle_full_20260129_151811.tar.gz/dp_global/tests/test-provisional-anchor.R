library(testthat)
library(data.table)

context("Provisional anchor behavior for DP")

small_dt <- data.table(
  Tag = rep(999L, 5),
  CensusID = c(3L,4L,5L,6L,7L),
  DBH = c(NA_real_, NA_real_, 1.0, 1.5, 2.0),
  TrueStemID = as.integer(NA),
  ReconstructedStemID = as.integer(NA),
  ReconstructionMethod = NA_character_
)

# Skip tests if function not available in this environment
skip_if_not(exists("match_stems_dp_global_backward_marginals_batch"), message = "DP function not available in this environment")

test_that("allow_provisional_anchor allows DP when anchor census has DBH but missing TrueStemID", {
  dt <- copy(small_dt)
  res <- match_stems_dp_global_backward_marginals_batch(dt, anchor_start = 7L, min_growth = -10, max_growth = 30, allow_provisional_anchor = TRUE, verbose = FALSE)
  # Should have at least some provisional DP assignments
  expect_true(any(res$ReconstructionMethod == "provisional_dp"))
  expect_true(any(!is.na(res$ReconstructedStemID)))
})

test_that("without provisional anchor DP falls back to igraph", {
  dt <- copy(small_dt)
  res <- match_stems_dp_global_backward_marginals_batch(dt, anchor_start = 7L, min_growth = -10, max_growth = 30, allow_provisional_anchor = FALSE, verbose = FALSE)
  # Should contain an igraph-based reconstruction
  expect_true(any(res$ReconstructionMethod %in% c("provisional_igraph", "igraph")))
})

# Confirm function default uses provisional anchor (no explicit flag) now that default is TRUE
test_that("default behavior uses provisional anchor (function default TRUE)", {
  dt <- copy(small_dt)
  res <- match_stems_dp_global_backward_marginals_batch(dt, anchor_start = 7L, min_growth = -10, max_growth = 30, verbose = FALSE)
  # Should have provisional DP assignments
  expect_true(any(res$ReconstructionMethod == "provisional_dp"))
  expect_true(any(!is.na(res$ReconstructedStemID)))
})
